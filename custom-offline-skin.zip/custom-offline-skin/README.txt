===================================
=Custom Offline Skin Resourcepack!=
=======Made by GhostIsBeHere=======
===================================

vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
>If you use in a video or something like that, give me credit in description!<
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Instructions:
1. Locate your Minecraft skin file (should be a .PNG or .png)
2. Determine whether your skin has 3-pixel arms (Alex) or 4-pixel arms (Steve)
3. Make a copy of your skin file
4. Rename the copy of your skin file to be alex.png (if it has 3-pixel arms) or steve.png (if it has 4-pixel arms)
4.5. If you can\'92t figure it out, make two copies and rename each of them steve.png and alex.png
6. Take the renamed file(s) and put them in the Custom Offline Skin folder
7. Open the Custom Offline Skin folder
8. Put skin file(s) in the assets folder
9. Open assets folder
10. Put skin file(s) in minecraft folder
11. Open minecraft folder
12. Put skin file(s) in textures folder
13. Open textures folder
14. Put skin file(s) in entity folder
15. Put Custom Offline Skin folder in Minecraft's resourcepacks folder
16. Enable resourcepack!
17. You are done!